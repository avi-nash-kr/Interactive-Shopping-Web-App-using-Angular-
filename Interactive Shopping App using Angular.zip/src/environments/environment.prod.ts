export const environment = {
  firebase: {
    projectId: 'student-management-a2291',
    appId: '1:375794119069:web:655363938c32625072ff74',
    storageBucket: 'student-management-a2291.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyCYrAcmaBg89Vj7n_4Y4gpGH1A7exmowPs',
    authDomain: 'student-management-a2291.firebaseapp.com',
    messagingSenderId: '375794119069',
  },
  production: true
};
