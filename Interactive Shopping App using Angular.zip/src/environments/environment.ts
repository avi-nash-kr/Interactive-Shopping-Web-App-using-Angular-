// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    projectId: 'student-management-a2291',
    appId: '1:375794119069:web:655363938c32625072ff74',
    storageBucket: 'student-management-a2291.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyCYrAcmaBg89Vj7n_4Y4gpGH1A7exmowPs',
    authDomain: 'student-management-a2291.firebaseapp.com',
    messagingSenderId: '375794119069',
  }
  
};


// const firebaseConfig = {
//   apiKey: "AIzaSyDFAeoZdq2790l0GVBwi6ciB-4qnhdABDE",
//   authDomain: "hackthon-f5ebb.firebaseapp.com",
//   projectId: "hackthon-f5ebb",
//   storageBucket: "hackthon-f5ebb.appspot.com",
//   messagingSenderId: "356467257786",
//   appId: "1:356467257786:web:6d71250146eb077c3c6d83"
// };
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
