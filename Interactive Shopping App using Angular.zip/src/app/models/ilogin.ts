export class ILogin {      
    userid: string='';    
    password: string='';    
  }  