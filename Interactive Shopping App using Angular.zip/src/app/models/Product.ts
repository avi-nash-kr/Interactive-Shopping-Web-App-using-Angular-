export interface Product {
    id: number,

    Productname: string,

    qty: number,

    photo: string
}