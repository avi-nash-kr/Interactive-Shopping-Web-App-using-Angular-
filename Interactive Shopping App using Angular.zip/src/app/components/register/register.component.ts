import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public email:string ='';
  public password:string  ='';

  constructor(private auth:AuthService,
    private router:Router) { }

  ngOnInit(): void {
  }

   //register method
   register(){

    if(this.email==''){
      alert('Please enter mail');
      return;
    }

    if(this.password==''){
      alert('Please enter password');
      return;
    }

    this.auth.register(this.email,this.password);
    this.email='';
    this.password='';
    // this.router.navigate(['login']);


  }

}
