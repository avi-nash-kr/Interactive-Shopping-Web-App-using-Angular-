import { Component, OnInit } from '@angular/core';
import { Router, TitleStrategy } from '@angular/router';
import { Product } from 'src/app/models/Product';
import { CustomerorderService } from 'src/app/service/customerorder.service';
import { AuthService } from 'src/app/service/auth.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public products:Product[]=[];
  public prod:Product={} as Product;
  id: string | null | undefined;

  constructor(private cuts:CustomerorderService,
              private auth:AuthService, private router:Router) { }

  ngOnInit(): void {

    this.id = localStorage.getItem('token'); 

    this.getAllProductsFromServer();
  }

  //fetch products
  public getAllProductsFromServer(){
    this.cuts.fetchProduct().subscribe((res:Product[])=>{
      this.products=res;
    }, err=>{
      alert(err.message);
    })
  }

  //add Product
  public productadd(){
    this.cuts.addProduct(this.prod).subscribe((res:any)=>{
      this.ngOnInit();
    }, err=>{
      alert(err.message);
    })
  }

  logout(){
    this.auth.logout();
    
    this.router.navigate(['/home']);
  }

//delete product
  public clickDelete(productId:number){
    this.cuts.deleteProduct(productId).subscribe((res:any)=>{
      this.ngOnInit();
    }, err=>{
      alert(err.message);
    })


  }


}
