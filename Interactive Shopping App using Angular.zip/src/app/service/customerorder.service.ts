import { Injectable } from '@angular/core';
import { Product } from '../models/Product';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerorderService {

  private  serverUrl:string='http://localhost:9000' ; // json-server url

  constructor(private httpClient:HttpClient) { }

  // fetch Products
  public fetchProduct(): Observable<Product[]> {
    let dataURL: string = `${this.serverUrl}/products`;
    return this.httpClient.get<Product[]>(dataURL);
  }

   // Add Product
   public addProduct(product: Product): Observable<Product> {
    let dataURL: string = `${this.serverUrl}/products`;
    return this.httpClient.post<Product>(dataURL, product);
  }

   // delete a contact
   public deleteProduct(productId: number): Observable<Product> {
    let dataURL: string = `${this.serverUrl}/products/${productId}`;
    return this.httpClient.delete<Product>(dataURL);
  }



}
