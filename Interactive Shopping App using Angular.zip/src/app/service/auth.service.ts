import { Injectable } from '@angular/core';
import { AngularFireAuth} from '@angular/fire/compat/auth';
import { Router } from '@angular/router';
import { GoogleAuthProvider, GithubAuthProvider,FacebookAuthProvider} from '@angular/fire/auth'

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  auth: any;

  constructor(private fireauth:AngularFireAuth,
    private router:Router) { }

     //login method
     login(email:string, password:string){
      this.fireauth.signInWithEmailAndPassword(email, password).then(res=>{
        localStorage.setItem('token','true');
        this.router.navigate(['home']);

        if(res.user?.emailVerified==true){
          this.router.navigate(['home']);
        }else{
          this.router.navigate(['/verify-email']);
        }
      }, err=>{
        alert(err.message);
        this.router.navigate(['/login']);
      })
    }

    //register method
    register(email:string, password:string){
      this.fireauth.createUserWithEmailAndPassword(email, password).then(res=>{
        alert('Registration Successfull');
        this.router.navigate(['/login']);
        this.sendEmailForVerification(res.user);
      }, err =>{
        alert(err.message);
        this.router.navigate(['/register']);
      })
    }

    // Sign Out
   logout(){
      this.fireauth.signOut().then(()=>{
        localStorage.removeItem('token');
        this.router.navigate(['/home']);
      },err =>{
        alert(err.message);
      })
    }
    //forgot-password method
    forgotPassword(email:string){
      this.fireauth.sendPasswordResetEmail(email).then(()=>{
        this.router.navigate(['/verify-email']);
      }, err=>{
        alert(err.message);
      });
    }

    //Email verification
    sendEmailForVerification(user:any){
      user.sendEmailVerification().then((res:any)=>{
        this.router.navigate(['/verify-email']);
      }, (err:any)=>{
        alert(err.message);
      });
    }

    //signInWithGoogle method
    GoogleSignin(){
      return this.fireauth.signInWithPopup(new GoogleAuthProvider).then((res)=>{

        this.router.navigate(['/home']);
        localStorage.setItem('token',JSON.stringify(res.user?.uid));
      }, err=>{
        alert(err.message);
      })
    }


    //is logged in
    
}
