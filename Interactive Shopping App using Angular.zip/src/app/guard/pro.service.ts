import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProService {

  constructor() { }

  logout() :void { 
      
    localStorage.setItem('isLoggedIn','false');    
    localStorage.removeItem('token');    
    }

  IsLoggedIn(){
    return !! localStorage.getItem('token');
  }

}
