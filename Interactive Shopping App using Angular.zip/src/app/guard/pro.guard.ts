import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { ProService} from '../guard/pro.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProGuard implements CanActivate{

  constructor(private auth:ProService, private router:Router){

  }
 

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot):  boolean  {
      if (this.auth.IsLoggedIn()){
    return true;
  }
  this.router.navigate(['/login']);      
  return false;      
  }  

  /**
   * isLoggedIn
   */
  // public isLoggedIn(): boolean {      
  //     let status = false;      
  //     if (localStorage.getItem('isLoggedIn') == "true") {      
  //        status = true;      
  //     }
  //       else {      
  //        status = false;      
  //        }      
  //     return status;      
  //     }    



   
  }




  // canActivateChild(
  //   childRoute: ActivatedRouteSnapshot,
  //   state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
  //   return true;
  // }
  

